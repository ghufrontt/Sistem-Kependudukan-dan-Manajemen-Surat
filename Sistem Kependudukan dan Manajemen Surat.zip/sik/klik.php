<html>
	<title>Keluar</title>
	<head>
		<center>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p><font size="6" color=#CC00000> Apakah Yakin Anda Ingin Keluar?</font></p>
			<p><a href="index.php"><font size="6" color=#CC00000>(YA<img src="img/ok.png" width="29" height="22"/>)</font></a> 					
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
		    <a href="home.html"><font size="6" color=#CC00000>(TIDAK<img src="img/no.png" width="30" height="22"/>)</font></a>
            </p>
		</center>
	</head>
</html>
