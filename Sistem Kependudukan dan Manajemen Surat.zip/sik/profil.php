<html>
	<title>Profil Desa Kedungsari</title>
	<head>
	    <p>
	      <center>
	        <img src="img/profil.png" width="102" height="116" />
            </font>
          </center>
        </p>
	    <p>
	      <center>
	        <font size="5" color="orange">PEMERINTAH KABUPATEN PROBOLINGGO</font>
          </center>
        </p>
	    <p>
	      <center>
	        <font size="5" color="orange">KECAMATAN MARON </font>
          </center>
        </p>
	    <p>
	      <center>
	        <font size="5" color="orange">DESA KEDUNGSARI</font>
          </center>
        </p>
	    <center>
	      <img src="img/kantor.jpg" width="412" height="318">	<img src="img/staff.jpg" width="326" height="316" />
          
        </center>
	</head>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
	    </html>
