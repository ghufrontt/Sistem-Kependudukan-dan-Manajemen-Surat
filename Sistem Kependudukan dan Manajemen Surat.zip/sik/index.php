<html>
	<title>Form Login - Jaranguda.com</title>
	<head>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
		<table width="316" height="155" align="center">
			<form name="form1" method="post" action="ceklogin.php">
			<tr>
 
				<td colspan="3"><strong>Form Login</strong></td>
			</tr>
			<tr>
				<td width="98">Username</td>
				<td width="6">:</td>
				<td width="216"><input name="username" type="text" id="username"/>
				</td>
			</tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="password" type="password" id="password"/></td>
			</tr>
			<tr>
				<td><input type="submit" name="Submit" value="Login"/></td>
			</tr>
		</form>
		</table>
	</head>
</html>
