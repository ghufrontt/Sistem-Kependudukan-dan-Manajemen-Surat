<?php
$username= $_POST['username'];
$password=$_POST['password'];

$db  = 'sik';
$host = 'localhost';
$user = 'root';
$pass = '';
$mysqli = new mysqli($host, $user, $pass, $db);
if (mysqli_connect_errno()) {
printf("Connect failed: %s\n", mysqli_connect_error());
exit();
}

$query = "SELECT * FROM login WHERE username='$username' and password='$password'";
$result = $mysqli->query($query) or die($mysqli->error.__LINE__);

if($result->num_rows > 0) {
echo 
 header("Location: home.html");
}
else {
echo 'username/password yang anda masukkan salah. Silahkan ulang kembali';	
}

?>
